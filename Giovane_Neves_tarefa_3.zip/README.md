# Creating a TikTok Clone

_The project consists of recreating the TikTok application, with technologies such as React._

## Diary:

### Day 01: Installing React and studying the starter example.
